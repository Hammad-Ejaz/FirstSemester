#include <iostream>
using namespace std;

const int rows = 3;
const int cols = 5;
void parking_exit(int [rows][cols]);
void printMovement(int, int);
bool findIn2d(int [rows][cols], int, int&, int&);
bool findInRow(int [cols], int, int&);

int main(){
    int arr[rows][cols] = {
        {2, 0, 0, 1, 0},
        {0, 0, 0, 1, 0},
        {0, 0, 0, 0, 0},
    };

    parking_exit(arr);
}

void parking_exit(int array[rows][cols]){
    int playerX = -1, playerY = -1, destY = rows - 1, destX = cols - 1;
    int nextX = 0, addY = 0;

    if(!findIn2d(array, 2, playerX, playerY)){
        cout << "starting position pointer not found in array" << endl;
        return;
    }

    while(playerY != destY){
        if(!findInRow(array[playerY], 1, nextX)){
            cout << "Invalid maze" << endl;
            return;
        }

        printMovement(nextX - playerX, 0);
        playerX = nextX;

        addY = 0;

        while(array[playerY + addY][playerX] == 1){
            addY += 1;
        }

        printMovement(0, addY);
        playerY += addY;
    }

    printMovement(destX - playerX, 0);
}

void printMovement(int x, int y){
    if(x != 0){
        if(x < 0){
            cout << "Left: " << -1 * x << endl;
        }
        else {
            cout << "Right: " << x << endl;
        }
    }
    else if(y != 0){
        if(y < 0){
            cout << "Up: " << -1 * y << endl;
        }
        else {
            cout << "Down: " << y << endl;
        }
    }
}

bool findIn2d(int a[rows][cols], int n, int& X, int& Y){
    for(int y = 0; y < rows; y++){
        for(int x = 0; x < cols; x++){
            if(a[y][x] == n){
                X = x;
                Y = y;
                return true;
            }
        }
    }

    return false;
}

bool findInRow(int r[cols], int n, int& X){
    for(int i = 0; i < cols; i++){
        if(r[i] == n){
            X = i;
            return true;
        }
    }

    return false;
}