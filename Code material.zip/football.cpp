#include <iostream>
#include <windows.h>
using namespace std;

struct player
{
    string name;
    string position;
    int touches;
    int catches;
    int passings;
    int receivings;
    int rushing;
};
int count = 0;
player info[10];

int menu()
{
    int op;
    cout << "1- Input data" << endl;
    cout << "2- Output data" << endl;
    cout << "3- Search data" << endl;
    cout << "4- Update data" << endl;
    cout << "Press 0 to exit" << endl;

    cin >> op;
    return op;
}
player input()
{
    player record;
    cout << "Name: ";
    cin >> record.name;
    cout << "Position: ";
    cin >> record.position;
    cout << "Touches: ";
    cin >> record.touches;
    cout << "Catches: ";
    cin >> record.catches;
    cout << "Passings: ";
    cin >> record.passings;
    cout << "Receiving: ";
    cin >> record.receivings;
    cout << "Rushings: ";
    cin >> record.rushing;

    return record;
}

void output(player record)
{
    cout << "Name: " << record.name << endl;
    cout << "Position: " << record.position << endl;
    cout << "Touches: " << record.touches << endl;
    cout << "Catches: " << record.catches << endl;
    cout << "Passings: " << record.passings << endl;
    cout << "Receiving: " << record.receivings << endl;
    cout << "Rushings: " << record.rushing << endl;
    cout << endl << endl;
}

int index(string nam)
{
    for (int i = 0; i < count - 1; i++)
    {
        if (info[i].name == nam)
        {
            return i;
        }
    }
}

void update(int i)
{
    cout << "Name: ";
    cin >> info[i].name;
    cout << "Position: ";
    cin >> info[i].position;
    cout << "Touches: ";
    cin >> info[i].touches;
    cout << "Catches: ";
    cin >> info[i].catches;
    cout << "Passings: ";
    cin >> info[i].passings;
    cout << "Receiving: ";
    cin >>info[i].receivings;
    cout << "Rushings: ";
    cin >> info[i].rushing;
}
main()
{
    int menuOp = menu();
    while (menuOp != 0)
    {
        if (menuOp == 1)
        {
            if (count < 10)
            {
                info[count] = input();
                count++;
            }
            else
            {
                cout << "Limit reached";
            }
            cout << endl;
            system("pause");
            system("cls");
            menuOp = menu();
            system("cls");
        }
        else if (menuOp == 2)
        {
            {
                for (int i = 0; i < count; i++)
                {
                    cout << "Player: " << i + 1 << endl
                         << endl;
                    output(info[i]);
                }
                cout << endl;
                system("pause");
                system("cls");
                menuOp = menu();
                system("cls");
            }
        }
        else if (menuOp == 3)
        {
            cout << "Name: ";
            string name;
            cin >> name;
            int i = index(name);
            system("cls");
            output(info[i]);

            cout << endl;
            system("pause");
            system("cls");
            menuOp = menu();
            system("cls");
        }
        else if (menuOp == 4)
        {
            cout << "Name: ";
            string name;
            cin >> name;
            int i = index(name);
            system("cls");
            update(i);

            cout << endl;
            system("pause");
            system("cls");
            menuOp = menu();
            system("cls");
        }
    }
}
