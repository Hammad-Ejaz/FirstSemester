#include <iostream>
#include <windows.h>
using namespace std;

struct marks {
    string subject;
    float data;
    marks *next;
};

struct student {
    string name;
    student *next;
    marks *m_next;
};

student *head = NULL;
HANDLE stdoutHandle = GetStdHandle(STD_OUTPUT_HANDLE);

unsigned mainMenu();
void addUserRecord(string, string, float);
void addSubjectRecord(student*, marks*);
void displayStudent(student*);
void showAllUsers();
void gotoxy(short, short);

int main(){
    string name, subject;
    float marksSubject;

    while(true){
        system("cls");
        showAllUsers();

        cout << "Enter Name: ";
        getline(cin >> ws, name);
        cout << "Enter Subject: ";
        getline(cin >> ws, subject);
        cout << "Enter Marks: ";
        cin >> marksSubject;

        addUserRecord(name, subject, marksSubject);
    }
}

void gotoxy(short x, short y){
    COORD coord = {x, y};

    SetConsoleCursorPosition(stdoutHandle, coord);
}

void printSubject(marks* m){
    CONSOLE_SCREEN_BUFFER_INFO csbi;

    cout << " -> ";
    GetConsoleScreenBufferInfo(stdoutHandle, &csbi);

    cout << m->subject;
    gotoxy(csbi.dwCursorPosition.X, csbi.dwCursorPosition.Y + 1);

    cout << m->data;
    gotoxy(csbi.dwCursorPosition.X + m->subject.length(), csbi.dwCursorPosition.Y);
}

void displayStudent(student* stu){
    marks* temp;
    cout << stu->name;
    temp = stu->m_next;

    while(temp != NULL){
        printSubject(temp);
        temp = temp->next;
    }

    cout << endl << endl;
}

void showAllUsers() {
    student* temp = head;

    while(temp != NULL){
        displayStudent(temp);

        temp = temp->next;
    }
}

void addUserRecord(string name, string subjectName, float subjectMarks) {
    marks *m = new marks {subjectName, subjectMarks, NULL};
    student *stu = new student {name, NULL, m};
    student *temp = head, *prev = head;

    if(head == NULL){
        head = stu;
        return;
    }

    while(temp != NULL){
        if(temp->name == name){
            addSubjectRecord(temp, m);
            return;
        }
        prev = temp;
        temp = temp->next;
    }

    prev->next = stu;
}
void addSubjectRecord(student* stu, marks* m) {
    marks *temp = stu->m_next, *prev = temp;

    while(temp != NULL){
        if(temp->subject == m->subject){
            temp->data = m->data;
            return;
        }
        prev = temp;
        temp = temp->next;
    }

    prev->next = m;
}