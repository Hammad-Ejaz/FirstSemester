#include<iostream>
using namespace std;
int main(){
float num1,num2,num3,num4,num5,num6;
char op;
cout << "---------------------------------" << endl;
cout << "|          CALCULATOR           |" << endl;
cout << "---------------------------------" << endl;
cout << endl;
cout<<"enter the operater ( +  ,  - ,  * , / )   : ";
cin>>op;
cout << endl;
cout<<"enter the frist number :";
cin>>num1;
cout << endl;
cout<<"enter the second number";
cin>>num2;
cout << endl;
if(op=='+')
{num3=num1+num2;
cout<<num1<<"+"<<num2<<" = "<<num3<<endl;}
else if(op=='-')
{num4=num1-num2;
cout<<num1<<"-"<<num2<<" = "<<num4<<endl;}
else if(op=='/')
{num5=num1/num2;
cout<<num1<<" / "<<num2<<" = "<<num5<<endl;}
else if(op=='*')
{num6=num1*num2;
cout<<num1<<"*"<<num2<<" = "<<num6<<endl;}
}






